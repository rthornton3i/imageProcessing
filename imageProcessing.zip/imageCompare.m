%% Compare Images to Stacked Image
%{
    Author: Richard Thornton
    Last Revision: 12/10/18
%}

%{ 
    [DETAILS] The following code compares a stacked, multi-layered image 
    to the individual layers.

    [UNITS] N/a

    [ASSUMPTIONS]
        
%}

%% Setup
clear;
clc;

addpath(genpath('Functions'));
addpath(genpath('Images'));

%% Read Image

fileName = 'lakeandballoon.bmp';
img = imread(fileName);
imgSize = [size(img,1),size(img,2),size(img,3)];
imgBi = de2bi(img);

for n = 1:length(imgBi)
    if imgBi(n,1) == 1
        imgBi(n,1) = 0;
    else
        imgBi(n,1) = 1;
    end
end

imgDe = bi2de(imgBi);

newImg = reshape(imgDe,[imgSize(1),imgSize(2),imgSize(3)]);

imwrite(newImg,'test.bmp');

%% Compare Images

for n = 1:numLayers
    imgDiff(:,:,n) = procImg - layerImgs(:,:,n);
    
    imgPercDiff(:,:,n) = (procImg - layerImgs(:,:,n)) * 100;
end

%% Batch Areas
%Batch target areas into larger "bins" for simplified analysis

% binDims = [32,32];
% 
% [imgBin] = imgBin(binDims,imgSize,numLayers,imgDiff);

%% Plot

rows = ceil(sqrt(numLayers));
colms = round(sqrt(numLayers));

[x,y] = meshgrid(1:imgSize(2),1:imgSize(1));

figure(1)
for n = 1:numLayers
    subplot(rows,colms,n)
    surf(x,y,imgDiff(:,:,n),'EdgeColor','none','FaceAlpha',0.7)
    title(['Layer ',num2str(n)])
    xlabel('X')
    ylabel('Y')
    zlabel('Radiance Difference')
end

figure(2)
for n = 1:numLayers
    subplot(rows,colms,n)
    surf(x,y,imgPercDiff(:,:,n),'EdgeColor','none','FaceAlpha',0.7)
    title(['Layer ',num2str(n)])
    xlabel('X')
    ylabel('Y')
    zlabel('Percent Radiance Difference')
end

% figure(3) 
% for n = 1:numLayers
%     subplot(rows,colms,n)
%     surf(x,y,imgBin(:,:,n),'EdgeColor','none','FaceAlpha',0.7)
%     title(['Layer ',num2str(n)])
%     xlabel('X')
%     ylabel('Y')
%     zlabel('Radiance Difference')
% end