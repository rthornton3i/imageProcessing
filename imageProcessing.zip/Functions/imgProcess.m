function [procImg,layerImgs,imgSize] = imgProcess(img,numLayers)
%Normalize and process image

%Crop pixels without multiple layers
index = numLayers - 1;
cropHt = numLayers^2 - numLayers;

img(1:cropHt,:) = [];
img(end-(cropHt-1):end,:) = [];

imgSize = [(size(img,1)/numLayers)-index,size(img,2)];

%Convert image
for n = 1:imgSize(1)
    %Identify rows from original image with same target area
    index = numLayers - 1;
    for m = 1:numLayers
        rows(m) = (numLayers * n) + ((m-1) * index);
    end
    
    %Stacked image
    for m = 1:length(rows)
        imgData(m,:) = img(rows(m),:);
    end
    
    procImg(n,:) = mean(imgData,1);
    
    %Individual images
    for m = 1:length(rows)
        layerImgs(n,:,m) = imgData(m,:);
    end
end
end

