function [scaleImg] = imgScale(img)
%Scale image for appropriate brightness.

tempArray = reshape(img,[1,numel(img)]);
scaleVal = 1/max(tempArray);
scaleImg = img .* scaleVal;
end

